import numpy as numpy
import csv

if __name__ == "__main__":
    #f = open('colliders.csv')
    #csv_reader = csv.reader(f)

   with open('colliders.csv') as file_obj:
      
    # Create reader object by passing the file 
    # object to reader method
    reader_obj = csv.reader(file_obj)
      
    # Iterate over each row in the csv 
    # file using reader object
    count = 0
    
    for row in reader_obj:
        if (count == 0):
            elem1 = row[0]
            elem2 = row[1]
            val = float(elem1[5:])
            val2 = float(elem2[5:])
            print(val)
            print(val2)
            count += 1 
        else:
            break